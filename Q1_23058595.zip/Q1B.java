import java.util.Random;
import java.util.HashMap;

public class Q1B {

    HashMap<Integer, int[]> arrayMap = new HashMap<>();

    public Q1B() {
        arrayMap.put(1, new int[1000]);
        arrayMap.put(2, new int[5000]);
        arrayMap.put(3, new int[10000]);
        arrayMap.put(4, new int[50000]);
        arrayMap.put(5, new int[75000]);
        arrayMap.put(6, new int[100000]);
        arrayMap.put(7, new int[500000]);
    }

    static int randomiser() {
        Random random = new Random();
        int randomNumber = random.nextInt(500000 - 1000 + 1) + 1000;
        return randomNumber;
    }

    public static void main(String[] args) {
        Q1B q1b = new Q1B();

        for (int key = 1; key <= 7; key++) {
            int[] currentArray = q1b.arrayMap.get(key);
            long startTime = System.currentTimeMillis();

            for (int i = 0; i < currentArray.length; i++) {
                currentArray[i] = randomiser();
            }

            long arrayCreationTime = System.currentTimeMillis() - startTime;
            startTime = System.currentTimeMillis();
            quickSort(currentArray, 0, currentArray.length - 1);
            long sortingTime = System.currentTimeMillis() - startTime;

            String currentDay = "";
            switch (key) {
                case 1:
                    currentDay = "Monday";
                    break;
                case 2:
                    currentDay = "Tuesday";
                    break;
                case 3:
                    currentDay = "Wednesday";
                    break;
                case 4:
                    currentDay = "Thursday";
                    break;
                case 5:
                    currentDay = "Friday";
                    break;
                case 6:
                    currentDay = "Saturday";
                    break;
                case 7:
                    currentDay = "Sunday";
                    break;
            }

            System.out.println("For " + currentDay + ": ");
            System.out.println("Array creation time: " + arrayCreationTime + " milliseconds");
            System.out.println("Sorting time: " + sortingTime + " milliseconds");
            System.out.println();
        }
    }

    static int pointer(int arr[], int low, int high) {
        int pivot = arr[high];
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1;
    }

    static void quickSort(int arr[], int low, int high) {
        if (low < high) {
            int pi = pointer(arr, low, high);
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

    static void printArray(int arr[]) {
        for (int i = 0; i < arr.length; ++i)
            System.out.print(arr[i] + " ");
        System.out.println();
    }
}