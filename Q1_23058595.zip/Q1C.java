import java.util.Random;
import java.util.HashMap;

public class Q1C {

    HashMap<Integer, int[]> arrayMap = new HashMap<>();

    public Q1C() {
        arrayMap.put(1, new int[1000]);
        arrayMap.put(2, new int[5000]);
        arrayMap.put(3, new int[10000]);
        arrayMap.put(4, new int[50000]);
        arrayMap.put(5, new int[75000]);
        arrayMap.put(6, new int[100000]);
        arrayMap.put(7, new int[500000]);
    }

    static int randomiser() {
        Random random = new Random();
        int randomNumber = random.nextInt(500000 - 1000 + 1) + 1000;
        return randomNumber;
    }

    public static void main(String[] args) {
        Q1C hybridQuicksort = new Q1C();

        for (int key = 1; key <= 7; key++) {
            int[] currentArray = hybridQuicksort.arrayMap.get(key);

            for (int i = 0; i < currentArray.length; i++) {
                currentArray[i] = randomiser();
            }
            int arrayLength = 0;
            String currentDay = "";
            switch (key) {
                case 1:
                    currentDay = "Monday";
                    arrayLength = 1000;
                    break;
                case 2:
                    currentDay = "Tuesday";
                    arrayLength = 5000;
                    break;
                case 3:
                    currentDay = "Wednesday";
                    arrayLength = 10000;
                    break;
                case 4:
                    currentDay = "Thursday";
                    arrayLength = 50000;
                    break;
                case 5:
                    currentDay = "Friday";
                    arrayLength = 75000;
                    break;
                case 6:
                    currentDay = "Saturday";
                    arrayLength = 100000;
                    break;
                case 7:
                    currentDay = "Sunday";
                    arrayLength = 50000;
                    break;
            }

            hybridQuickSort(currentArray, 0, currentArray.length - 1);
            System.out.println("Sorted items for " + currentDay + ": ");
            printArray(currentArray);
        }
    }

    static int pointer(int arr[], int low, int high) {
        int pivot = arr[high];
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1;
    }

    static void hybridQuickSort(int arr[], int low, int high) {
        if (low < high) {
            if (high - low + 1 <= 15) {
                insertionSort(arr, low, high);
            } else {
                int pi = pointer(arr, low, high);
                hybridQuickSort(arr, low, pi - 1);
                hybridQuickSort(arr, pi + 1, high);
            }
        }
    }

    static void insertionSort(int arr[], int low, int high) {
        for (int i = low + 1; i <= high; i++) {
            int key = arr[i];
            int j = i - 1;
            while (j >= low && arr[j] > key) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
    }

    static void printArray(int arr[]) {
        for (int i = 0; i < arr.length; ++i)
            System.out.print(arr[i] + "\t");
        System.out.println();
    }
}
